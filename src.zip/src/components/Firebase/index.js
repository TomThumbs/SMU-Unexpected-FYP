import FirebaseContext, { withFirebase } from './context';
import Firebase, { firestore } from './firebase';
// import Firebase from './firebase';

export default Firebase;

export { FirebaseContext, withFirebase, firestore };
